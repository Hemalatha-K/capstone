export class UserClass{
    
    id: number;
    name: string;
    dob:string;
    address:string;
    email: string;
    mobile:string;
    gender:string;
    
}